import 'dart:async';
import 'dart:typed_data';

import 'package:flutter_blue_plus/flutter_blue_plus.dart';

import 'transport.dart';

class BleTransport implements Transport {
  BluetoothDevice? device;
  BluetoothCharacteristic? tx;
  BluetoothCharacteristic? rxChar;

  final _rx = StreamController<Uint8List>.broadcast();

  @override
  String get id => 'ble';

  @override
  bool get isConnected => device != null;

  @override
  Stream<Uint8List> get rx => _rx.stream;

  Future<void> bind({
    required BluetoothDevice device,
    required BluetoothCharacteristic tx,
    required BluetoothCharacteristic rx,
  }) async {
    this.device = device;
    this.tx = tx;
    rxChar = rx;

    await rx.setNotifyValue(true);
    rx.lastValueStream.listen((data) => _rx.add(Uint8List.fromList(data)));
  }

  @override
  Future<void> send(Uint8List data) async {
    await tx?.write(data, withoutResponse: false);
  }

  @override
  Future<void> disconnect() async {
    await device?.disconnect();
    device = null;
  }
}
