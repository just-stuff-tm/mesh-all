import 'dart:typed_data';

import '../detect/detector.dart' as detector_module;
import '../transport/transport.dart';
import '../protocol/protocol.dart';

class MeshEngine {
  final Transport transport;
  final detector_module.MeshDetector detector;

  MeshProtocol? protocol;

  MeshEngine(this.transport, this.detector) {
    transport.rx.listen(_onData);
  }

  void _onData(Uint8List data) {
    protocol ??= detector.detect(data);
    protocol?.decode(data);
  }

  Future<void> send(dynamic message) async {
    if (protocol == null) return;
    await transport.send(protocol!.encode(message));
  }
}
