import '../transport/ble_transport.dart';
import '../transport/tcp_transport.dart';
import '../transport/usb_transport.dart';

class EngineProvider {
  static final ble = BleTransport();
  static final tcp = TcpTransport();
  static final usb = UsbTransport();

  static void init() {
    // Add your engine initialization logic here
    // For example:
    // - Initialize native bindings
    // - Set up engine configurations
    // - Perform any required setup
  }
}
