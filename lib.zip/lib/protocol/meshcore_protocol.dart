import 'dart:async';
import 'dart:typed_data';
import 'protocol.dart';

class MeshCoreProtocol implements MeshProtocol {
  @override
  ProtocolType get type => ProtocolType.meshCoreProtocol;

  @override
  dynamic decode(Uint8List bytes) {
    // TODO: implement decode
    throw UnimplementedError();
  }

  @override
  Uint8List encode(dynamic data) {
    // TODO: implement encode
    return Uint8List(0);
  }

  @override
  bool matches(Uint8List bytes) {
    // TODO: implement matches
    return false;
  }

  @override
  void onBytes(Uint8List bytes) {
    // TODO: implement onBytes
    throw UnimplementedError();
  }

  @override
  Stream<dynamic> get onMessage => throw UnimplementedError();
}
