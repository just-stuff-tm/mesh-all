import 'dart:async';
import 'dart:typed_data';
import 'protocol.dart';

class RNodeProtocol implements MeshProtocol {
  @override
  dynamic decode(Uint8List data) {
    // TODO: implement decode
    throw UnimplementedError();
  }

  @override
  Uint8List encode(dynamic message) {
    // TODO: implement encode
    throw UnimplementedError();
  }

  @override
  bool matches(Uint8List data) {
    // TODO: implement matches
    throw UnimplementedError();
  }

  @override
  void onBytes(Uint8List data) {
    // TODO: implement onBytes
    throw UnimplementedError();
  }

  @override
  Stream<dynamic> get onMessage => throw UnimplementedError();

  @override
  ProtocolType get type => throw UnimplementedError();
}
