import 'dart:typed_data';
import 'package:flutter/material.dart';

import '../core/engine_provider.dart';

class TcpState extends ChangeNotifier {
  String status = 'idle';
  bool isBusy = false;

  final List<String> log = [];

  Future<void> connect(String host, int port) async {
    if (isBusy) return;

    isBusy = true;
    status = 'connecting';
    notifyListeners();

    try {
      await EngineProvider.tcp.connect(host, port);

      status = 'connected';
      log.add('TCP connected to $host:$port');

      EngineProvider.tcp.rx.listen((Uint8List data) {
        log.add('RX ${data.length} bytes');
        notifyListeners();
      });
    } catch (e) {
      status = 'error: $e';
      log.add(status);
    }

    isBusy = false;
    notifyListeners();
  }

  Future<void> send(Uint8List data) async {
    await EngineProvider.tcp.send(data);
    log.add('TX ${data.length} bytes');
    notifyListeners();
  }

  Future<void> sendHello() async {
    await send(Uint8List.fromList([0x48, 0x69])); // "Hi"
  }
}
