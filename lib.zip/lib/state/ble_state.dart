import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';

import '../core/engine_provider.dart';
import '../core/permissions/ble_permissions.dart';

class BleState extends ChangeNotifier {
  List<ScanResult> devices = [];
  BluetoothDevice? connectedDevice;

  bool isScanning = false;
  String status = 'idle';

  int? batteryLevel;
  final List<String> log = [];

  /// START SCAN
  Future<void> startScan() async {
    final ok = await BlePermissions.request();
    if (!ok) {
      status = 'permissions denied';
      notifyListeners();
      return;
    }

    isScanning = true;
    devices.clear();
    notifyListeners();

    FlutterBluePlus.onScanResults.listen((results) {
      devices = results;
      notifyListeners();
    });

    await FlutterBluePlus.startScan(
      timeout: const Duration(seconds: 10),
    );

    isScanning = false;
    notifyListeners();
  }

  /// CONNECT
  Future<void> connect(BluetoothDevice device) async {
    status = 'connecting';
    notifyListeners();

    try {
      await device.connect();
      
      // Get services and characteristics
      final services = await device.discoverServices();
      BluetoothCharacteristic? txChar;
      BluetoothCharacteristic? rxChar;
      
      // Find TX and RX characteristics (adjust UUIDs based on your protocol)
      for (var service in services) {
        for (var char in service.characteristics) {
          // Adjust these UUIDs to match your device's service
          if (char.uuid.toString().toLowerCase().contains('tx')) {
            txChar = char;
          } else if (char.uuid.toString().toLowerCase().contains('rx')) {
            rxChar = char;
          }
        }
      }
      
      if (txChar != null && rxChar != null) {
        await EngineProvider.ble.bind(
          device: device,
          tx: txChar,
          rx: rxChar,
        );
      } else {
        throw Exception('TX or RX characteristic not found');
      }
      
      connectedDevice = device;
      status = 'connected';
      log.add('BLE connected');

      EngineProvider.ble.rx.listen(_onData);
    } catch (e) {
      status = 'error: $e';
    }

    notifyListeners();
  }

  /// DISCONNECT
  Future<void> disconnect() async {
    await EngineProvider.ble.disconnect();
    connectedDevice = null;
    batteryLevel = null;
    status = 'disconnected';
    notifyListeners();
  }

  /// SEND HELLO (UI EXPECTS THIS)
  Future<void> sendHello() async {
    await EngineProvider.ble.send(
      Uint8List.fromList([0x48, 0x65, 0x6c, 0x6c, 0x6f]),
    );
    log.add('TX: Hello');
    notifyListeners();
  }

  void _onData(Uint8List data) {
    final hex = data.map((b) => b.toRadixString(16).padLeft(2, '0')).join(' ');
    log.add('RX: $hex');
    notifyListeners();
  }

}
