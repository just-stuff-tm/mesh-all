import 'dart:async';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:usb_serial/usb_serial.dart';

import '../core/engine_provider.dart';

class UsbState extends ChangeNotifier {
  bool isConnected = false;
  String status = 'idle';

  List<UsbDevice> devices = [];
  final List<String> log = [];

  Future<void> refreshDevices() async {
    devices = await UsbSerial.listDevices();
    log.add('Found ${devices.length} USB devices');
    notifyListeners();
  }

  Future<void> connect(UsbDevice device) async {
    status = 'connecting';
    notifyListeners();

    try {
      await EngineProvider.usb.connect(device);
      status = 'connected';
      isConnected = true;
      log.add('USB connected');

      EngineProvider.usb.rx.listen((Uint8List data) {
        log.add('RX ${data.length} bytes');
        notifyListeners();
      });
    } catch (e) {
      status = 'error: $e';
    }

    notifyListeners();
  }

  Future<void> send(Uint8List data) async {
    await EngineProvider.usb.send(data);
    log.add('TX ${data.length} bytes');
    notifyListeners();
  }

  Future<void> sendHello() async {
    await send(Uint8List.fromList([0x48, 0x49]));
  }
}
